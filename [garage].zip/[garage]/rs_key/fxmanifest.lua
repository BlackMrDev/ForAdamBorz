fx_version 'adamant'
game 'gta5'


client_script {
    'dep/enumerator.lua',
    'main.lua',
}

server_script {
    "srv_main.lua",
}

client_script "AC-Sync.lua"