configuration = {
    casier = {
        {pos = vector3(441.45544433594,-976.86297607422,30.689306259155)}
    },

    webhook = {
        ["createCasier"] = "https://discord.com/api/webhooks/976967557158436895/QhoH9jTl4k51H5P6rYlBy5WBpwGmCZ1IGqxrGZ9fNJTTPUIbouHxiKKYzYDCzDuAYyno",
        ["supprCasier"] = "https://discord.com/api/webhooks/976964036912631909/bSov-RiMtgYO0UEFMiQX6d4vWizBLXcYTc13xBS1WY9GdBtVEO3gVf9Qru3KqfutXiBs", 
        ["addMotif"] = "https://discord.com/api/webhooks/977232818310623294/e4Edy9oT51EVR_PBxMpKYbCuAV6j1xmvSEIwonhHl_z8AQ0DahblMPG1F_Job3afmYqe", 
        ["supprMotif"] = "https://discord.com/api/webhooks/977232899336179762/kzTGI7C_JOhyhySpL_Qvxzp1mHzZ5nmfhohCFHGH_plFpSbZ-vNLi9BkOkuN8ukickCY",
        ["editMotif"] = "https://discord.com/api/webhooks/977246877164658758/ObPqm0L2FvACoDgQJnUnWxgnaKXssdo1FMJBoG8jqy0sLNbW3YuBqqwsMCS1qCGyJgrf"
    },
}
