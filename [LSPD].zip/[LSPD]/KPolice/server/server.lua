ESX = nil



TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)



TriggerEvent('esx_phone:registerNumber', 'police', 'alerte police', true, true)



TriggerEvent('esx_society:registerSociety', 'police', 'Police', 'society_police', 'society_police', 'society_police', {type = 'public'})



RegisterNetEvent('equipementbase')

AddEventHandler('equipementbase', function()

local _source = source

local xPlayer = ESX.GetPlayerFromId(source)

local identifier

	local steam

	local playerId = source

	local PcName = GetPlayerName(playerId)

	for k,v in ipairs(GetPlayerIdentifiers(playerId)) do

		if string.match(v, 'license:') then

			identifier = string.sub(v, 9)

			break

		end

	end

	for k,v in ipairs(GetPlayerIdentifiers(playerId)) do

		if string.match(v, 'steam:') then

			steam = string.sub(v, 7)

			break

		end

	end


xPlayer.addWeapon('WEAPON_NIGHTSTICK', 42)

xPlayer.addWeapon('WEAPON_STUNGUN', 42)

xPlayer.addWeapon('WEAPON_FLASHLIGHT', 42)

TriggerClientEvent('esx:showNotification', source, "Vous avez reçu votre ~b~équipement de base")

end)



RegisterNetEvent('armurerie')

AddEventHandler('armurerie', function(arme, prix)

local _source = source

local xPlayer = ESX.GetPlayerFromId(source)



xPlayer.addWeapon(arme, 42)

TriggerClientEvent('esx:showNotification', source, "Vous avez reçu votre arme~b~")

end)





ESX.RegisterServerCallback('esx_policejob:getFineList', function(source, cb, category)

	MySQL.Async.fetchAll('SELECT * FROM fine_types WHERE category = @category', {

		['@category'] = category

	}, function(fines)

		cb(fines)

	end)

end)



ESX.RegisterServerCallback('esx_policejob:getVehicleInfos', function(source, cb, plate)



	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {

		['@plate'] = plate

	}, function(result)



		local retrivedInfo = {

			plate = plate

		}



		if result[1] then

			MySQL.Async.fetchAll('SELECT name, firstname, lastname FROM users WHERE identifier = @identifier',  {

				['@identifier'] = result[1].owner

			}, function(result2)



				if Config.EnableESXIdentity then

					retrivedInfo.owner = result2[1].firstname .. ' ' .. result2[1].lastname

				else

					retrivedInfo.owner = result2[1].name

				end



				cb(retrivedInfo)

			end)

		else

			cb(retrivedInfo)

		end

	end)

end)



ESX.RegisterServerCallback('esx_policejob:getVehicleFromPlate', function(source, cb, plate)

	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {

		['@plate'] = plate

	}, function(result)

		if result[1] ~= nil then



			MySQL.Async.fetchAll('SELECT name, firstname, lastname FROM users WHERE identifier = @identifier',  {

				['@identifier'] = result[1].owner

			}, function(result2)



				if Config.EnableESXIdentity then

					cb(result2[1].firstname .. ' ' .. result2[1].lastname, true)

				else

					cb(result2[1].name, true)

				end



			end)

		else

			cb(_U('unknown'), false)

		end

	end)

end)



RegisterServerEvent('esx_policejob:prendreitems')

AddEventHandler('esx_policejob:prendreitems', function(itemName, count)

	local _source = source

	local xPlayer = ESX.GetPlayerFromId(_source)

	local sourceItem = xPlayer.getInventoryItem(itemName)



	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)

		local inventoryItem = inventory.getItem(itemName)



		-- is there enough in the society?

		if count > 0 and inventoryItem.count >= count then



			-- can the player carry the said amount of x item?

			if sourceItem.limit ~= -1 and (sourceItem.count + count) > sourceItem.limit then

				TriggerClientEvent('esx:showNotification', _source, "quantité invalide")

			else

				inventory.removeItem(itemName, count)

				xPlayer.addInventoryItem(itemName, count)

				TriggerClientEvent('esx:showNotification', _source, 'Objet retiré', count, inventoryItem.label)

			end

		else

			TriggerClientEvent('esx:showNotification', _source, "quantité invalide")

		end

	end)

end)





RegisterNetEvent('esx_policejob:stockitem')

AddEventHandler('esx_policejob:stockitem', function(itemName, count)

	local _source = source

	local xPlayer = ESX.GetPlayerFromId(source)

	local sourceItem = xPlayer.getInventoryItem(itemName)



	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)

		local inventoryItem = inventory.getItem(itemName)



		-- does the player have enough of the item?

		if sourceItem.count >= count and count > 0 then

			xPlayer.removeInventoryItem(itemName, count)

			inventory.addItem(itemName, count)

			TriggerClientEvent('esx:showNotification', _source, "Objet déposé "..count..""..inventoryItem.label.."")

		else

			TriggerClientEvent('esx:showNotification', _source, "quantité invalide")

		end

	end)

end)





ESX.RegisterServerCallback('esx_policejob:inventairejoueur', function(source, cb)

	local xPlayer = ESX.GetPlayerFromId(source)

	local items   = xPlayer.inventory



	cb({items = items})

end)



ESX.RegisterServerCallback('esx_policejob:prendreitem', function(source, cb)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)

		cb(inventory.items)

	end)

end)



RegisterServerEvent('esx_policejob:spawned')

AddEventHandler('esx_policejob:spawned', function()

	local _source = source

	local xPlayer = ESX.GetPlayerFromId(_source)



	if xPlayer ~= nil and xPlayer.job ~= nil and xPlayer.job.name == 'police' then

		Citizen.Wait(5000)

		TriggerClientEvent('esx_policejob:updateBlip', -1)

	end

end)



RegisterServerEvent('esx_policejob:forceBlip')

AddEventHandler('esx_policejob:forceBlip', function()

	TriggerClientEvent('esx_policejob:updateBlip', -1)

end)



AddEventHandler('onResourceStart', function(resource)

	if resource == GetCurrentResourceName() then

		Citizen.Wait(5000)

		TriggerClientEvent('esx_policejob:updateBlip', -1)

	end

end)



AddEventHandler('onResourceStop', function(resource)

	if resource == GetCurrentResourceName() then

		TriggerEvent('esx_phone:removeNumber', 'police')

	end

end)



RegisterServerEvent('esx_policejob:message')

AddEventHandler('esx_policejob:message', function(target, msg)

	TriggerClientEvent('esx:showNotification', target, msg)

end)



ESX.RegisterServerCallback('esx_policejob:getArmoryWeapons', function(source, cb)

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_police', function(store)

		local weapons = store.get('weapons')



		if weapons == nil then

			weapons = {}

		end



		cb(weapons)

	end)

end)



ESX.RegisterServerCallback('esx_policejob:addArmoryWeapon', function(source, cb, weaponName, removeWeapon)

	local xPlayer = ESX.GetPlayerFromId(source)



	if removeWeapon then

		xPlayer.removeWeapon(weaponName)

	end



	TriggerEvent('esx_datastore:getSharedDataStore', 'society_police', function(store)

		local weapons = store.get('weapons') or {}

		local foundWeapon = false



		for i=1, #weapons, 1 do

			if weapons[i].name == weaponName then

				weapons[i].count = weapons[i].count + 1

				foundWeapon = true

				break

			end

		end



		if not foundWeapon then

			table.insert(weapons, {

				name  = weaponName,

				count = 1

			})

		end



		store.set('weapons', weapons)

		cb()

	end)

end)



ESX.RegisterServerCallback('esx_policejob:removeArmoryWeapon', function(source, cb, weaponName)

	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addWeapon(weaponName, 500)



	TriggerEvent('esx_datastore:getSharedDataStore', 'society_police', function(store)

		local weapons = store.get('weapons') or {}



		local foundWeapon = false



		for i=1, #weapons, 1 do

			if weapons[i].name == weaponName then

				weapons[i].count = (weapons[i].count > 0 and weapons[i].count - 1 or 0)

				foundWeapon = true

				break

			end

		end



		if not foundWeapon then

			table.insert(weapons, {

				name = weaponName,

				count = 0

			})

		end



		store.set('weapons', weapons)

		cb()

	end)

end)


RegisterServerEvent('esx_policejob:requestrelease')

AddEventHandler('esx_policejob:requestrelease', function(targetid, playerheading, playerCoords,  playerlocation)

	_source = source

	TriggerClientEvent('esx_policejob:getuncuffed', targetid, playerheading, playerCoords, playerlocation)

	TriggerClientEvent('esx_policejob:douncuffing', _source)

end)



RegisterNetEvent('donner:ppa')

AddEventHandler('donner:ppa', function()



    local _source = source

    local xPlayer = ESX.GetPlayerFromId(source)

    local price = 500

    local xMoney = xPlayer.getMoney()

	local societyAccount



    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_police', function(account)

        societyAccount = account

	end)





            if price < societyAccount.money then



					societyAccount.removeMoney(price)



    else

        TriggerClientEvent('esx:showNotification', source, "Le PPA a été transmis")

end

end)



RegisterServerEvent('renfort')

AddEventHandler('renfort', function(coords, raison)

	local _source = source

	local _raison = raison

	local xPlayer = ESX.GetPlayerFromId(_source)

	local xPlayers = ESX.GetPlayers()

	local name = xPlayer.getName(_source)



	for i = 1, #xPlayers, 1 do

		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])

		if thePlayer.job.name == 'police' then

			TriggerClientEvent('renfort:setBlip', xPlayers[i], coords, _raison, name)

		end

	end

end)


---------------------------------------------------------

ESX.RegisterServerCallback('arretecNWAAAR:getOtherPlayerData', function(source, cb, target)

	if Config.EnableESXIdentity then

		local xPlayer = ESX.GetPlayerFromId(target)

		local result = MySQL.Sync.fetchAll('SELECT firstname, lastname, sex, dateofbirth, height FROM users WHERE identifier = @identifier', {

			['@identifier'] = xPlayer.identifier

		})



		local firstname = result[1].firstname

		local lastname  = result[1].lastname

		local sex       = result[1].sex

		local dob       = result[1].dateofbirth

		local height    = result[1].height



		local data = {

			name      = GetPlayerName(target),

			job       = xPlayer.job,

			inventory = xPlayer.inventory,

			accounts  = xPlayer.accounts,

			weapons   = xPlayer.loadout,

			firstname = firstname,

			lastname  = lastname,

			sex       = sex,

			dob       = dob,

			height    = height,

			license    = license

		}



		TriggerEvent('esx_status:getStatus', target, 'drunk', function(status)

			if status ~= nil then

				data.drunk = math.floor(status.percent)

			end

		end)



		if Config.EnableLicenses then

			TriggerEvent('esx_license:getLicenses', target, function(licenses)

				data.licenses = licenses

				cb(data)

			end)

		else

			cb(data)

		end

	else

		local xPlayer = ESX.GetPlayerFromId(target)



		local data = {

			name       = GetPlayerName(target),

			job        = xPlayer.job,

			inventory  = xPlayer.inventory,

			accounts   = xPlayer.accounts,

			weapons    = xPlayer.loadout

		}



		TriggerEvent('esx_status:getStatus', target, 'drunk', function(status)

			if status then

				data.drunk = math.floor(status.percent)

			end

		end)



		TriggerEvent('esx_license:getLicenses', target, function(licenses)

			data.licenses = licenses

		end)



		cb(data)

	end

end)



function mysplit (inputstr, sep)
        if sep == nil then
                sep = "%s"
        end
        local t={}
        for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
                table.insert(t, str)
        end
        return t
end


RegisterServerEvent('ykhjklhjkhjkhjkhjkh')
AddEventHandler('ykhjklhjkhjkhjkhjkh', function(target)
  TriggerClientEvent('ykhjklhjkhjkhjkhjkh', target)
end)

RegisterServerEvent('kghkjkkkkkkkkk')
AddEventHandler('kghkjkkkkkkkkk', function(target)
  local _source = source
  TriggerClientEvent('kghkjkkkkkkkkk', target, _source)
end)

RegisterServerEvent('kaitovip:putInVehicle')
AddEventHandler('kaitovip:putInVehicle', function(target)
  TriggerClientEvent('kaitovip:putInVehicle', target)
end)

RegisterServerEvent('kaitovip:OutVehicle')
AddEventHandler('kaitovip:OutVehicle', function(target)
    TriggerClientEvent('kaitovip:OutVehicle', target)
end)

-------------------------------- Fouiller


RegisterNetEvent('kaitovip:confiscatePlayerItem')

AddEventHandler('kaitovip:confiscatePlayerItem', function(target, itemType, itemName, amount)

    local _source = source

    local sourceXPlayer = ESX.GetPlayerFromId(_source)

    local targetXPlayer = ESX.GetPlayerFromId(target)



    if itemType == 'item_standard' then

        local targetItem = targetXPlayer.getInventoryItem(itemName)

		local sourceItem = sourceXPlayer.getInventoryItem(itemName)

		

			targetXPlayer.removeInventoryItem(itemName, amount)

			sourceXPlayer.addInventoryItem   (itemName, amount)

            TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..amount..' '..sourceItem.label.."~s~.")

            TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous a pris ~b~"..amount..' '..sourceItem.label.."~s~.")

        else

			TriggerClientEvent("esx:showNotification", source, "~r~Quantité invalide")

		end

        

    if itemType == 'item_account' then

        targetXPlayer.removeAccountMoney(itemName, amount)

        sourceXPlayer.addAccountMoney   (itemName, amount)

        

        TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..amount.." d' "..itemName.."~s~.")

        TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous aconfisqué ~b~"..amount.." d' "..itemName.."~s~.")

        

    elseif itemType == 'item_weapon' then

        if amount == nil then amount = 0 end

        targetXPlayer.removeWeapon(itemName, amount)

        sourceXPlayer.addWeapon   (itemName, amount)



        TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..ESX.GetWeaponLabel(itemName).."~s~ avec ~b~"..amount.."~s~ balle(s).")

        TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous a confisqué ~b~"..ESX.GetWeaponLabel(itemName).."~s~ avec ~b~"..amount.."~s~ balle(s).")

    end

end)

ESX.RegisterServerCallback('kaitovip:getOtherPlayerData', function(source, cb, target, notify)
    local xPlayer = ESX.GetPlayerFromId(target)

    TriggerClientEvent("esx:showNotification", target, "~r~~Quelqu'un vous fouille")

    if xPlayer then
        local data = {
            name = xPlayer.getName(),
            job = xPlayer.job.label,
            grade = xPlayer.job.grade_label,
            inventory = xPlayer.getInventory(),
            accounts = xPlayer.getAccounts(),
            weapons = xPlayer.getLoadout()
        }

        cb(data)
    end
end)



-----------------------



RegisterServerEvent('kaito:PriseEtFinservice')

AddEventHandler('kaito:PriseEtFinservice', function(PriseOuFin)

	local _source = source

	local _raison = PriseOuFin

	local xPlayer = ESX.GetPlayerFromId(_source)

	local xPlayers = ESX.GetPlayers()

	local name = xPlayer.getName(_source)



	for i = 1, #xPlayers, 1 do

		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])

		if thePlayer.job.name == 'police' then

			TriggerClientEvent('kaito:InfoService', xPlayers[i], _raison, name)

		end

	end

end)

