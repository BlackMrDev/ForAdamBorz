Config                            = {}

Config.DrawDistance               = 25.0

Config.Type = 21

Config.EnablePlayerManagement     = true

Config.EnableArmoryManagement     = true

Config.EnableESXIdentity          = true 

Config.EnableNonFreemodePeds      = false 

Config.EnableLicenses             = true 

Config.EnableHandcuffTimer        = true 

Config.HandcuffTimer              = 10 * 60000 

Config.EnableJobBlip              = true 

Config.MaxInService               = -1

Config.Locale                     = 'fr'

Config.WhitelistedCops = {

	'police'

}



Config.armurerie = {

	{nom = "Pistolet de combat", arme = "weapon_combatpistol"},

}



Config.arm = {

	{nom = "Pistolet de combat", arme = "weapon_compatpistol"},

	{nom = "Fusil à pompe", arme = "weapon_pumpshotgun"},

}





Config.armi = {

	{nom = "Pistolet de combat", arme = "weapon_combatpistol"},

	{nom = "Fusil à pompe", arme = "weapon_pumpshotgun"},

	{nom = "M4", arme = "weapon_carbinerifle"},

}







Config.PoliceStations = {}



