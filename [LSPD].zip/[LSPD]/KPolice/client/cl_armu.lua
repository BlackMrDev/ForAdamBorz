ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


function ArmupOLICE()
    local ArmupOLICE = RageUI.CreateMenu("Police", "Menu Intéraction..")
    ArmupOLICE:SetRectangleBanner(0, 0, 0)
        RageUI.Visible(ArmupOLICE, not RageUI.Visible(ArmupOLICE))
            while ArmupOLICE do
            Citizen.Wait(0)
            RageUI.IsVisible(ArmupOLICE, true, true, true, function()


                RageUI.ButtonWithStyle("Equipement de base", nil, { },true, function(Hovered, Active, Selected)

                    if (Selected) then   

                        TriggerServerEvent('equipementbase')

                    end

                end)

    

    

                if ESX.PlayerData.job.grade_name == 'officer' then

                    for k,v in pairs(Config.armurerie) do

                    RageUI.ButtonWithStyle(v.nom, nil, { },true, function(Hovered, Active, Selected)

                        if (Selected) then   

                            TriggerServerEvent('armurerie', v.arme, v.prix)

                        end

                    end)

                end

            end

    

                if ESX.PlayerData.job.grade_name == 'sergeant' then

                    for k,v in pairs(Config.arm) do

                    RageUI.ButtonWithStyle(v.nom, nil, { },true, function(Hovered, Active, Selected)

                        if (Selected) then   

                            TriggerServerEvent('armurerie', v.arme, v.prix)

                        end

                    end)

                end

            end

    

                        if ESX.PlayerData.job.grade_name == 'lieutenant' then

                        for k,v in pairs(Config.arm) do

                        RageUI.ButtonWithStyle(v.nom, nil, { },true, function(Hovered, Active, Selected)

                            if (Selected) then   

                                TriggerServerEvent('armurerie', v.arme, v.prix)

                            end

                        end)

                    end

                end

    

                if ESX.PlayerData.job.grade_name == 'boss' then

                    for k,v in pairs(Config.armi) do

                    RageUI.ButtonWithStyle(v.nom, nil, { },true, function(Hovered, Active, Selected)

                        if (Selected) then   

                            TriggerServerEvent('armurerie', v.arme, v.prix)

                        end

                    end)

                end

            end

    
    
            end, function()
            end, 1)

            if not RageUI.Visible(ArmupOLICE) then
            ArmupOLICE = RMenu:DeleteType("ArmupOLICE", true)
        end
    end
end


local position = {

    {x = 452.43 , y = -980.13, z = 30.68}
    
    }

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(position) do
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)
            DrawMarker(22, 452.43 , -980.13,  30.68, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 0, 0 , 255, true, true, p19, true)

            if dist <= 5.0 then
            wait = 0
        
            if dist <= 1.0 then
               wait = 0
			   RageUI.Text({

				message = "Appuyez sur [~r~E~w~] pour demander votre équipement",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then

                    exports['progressBars']:startUI((4 * 1000), _U('progbar_talking4'))

                    Citizen.Wait((4 * 1000))
					ArmupOLICE()
            end
        end
    end
    end
    Citizen.Wait(wait)
    end
end
end)


local npc2 = {

    {hash="csb_trafficwarden", x = 454.14 , y = -979.99, z = 30.68, a=89.97},

}



Citizen.CreateThread(function()

    for _, item2 in pairs(npc2) do

        local hash = GetHashKey(item2.hash)

        while not HasModelLoaded(hash) do

        RequestModel(hash)

        Wait(20)

        end

        ped2 = CreatePed("PED_TYPE_CIVFEMALE", item2.hash, item2.x, item2.y, item2.z-0.92, item2.a, false, true)

        TaskStartScenarioInPlace(ped2, 'WORLD_HUMAN_CLIPBOARD_FACILITY', 0, true)

        SetBlockingOfNonTemporaryEvents(ped2, true)

        FreezeEntityPosition(ped2, true)

        SetEntityInvincible(ped2, true)

    end

end)


local pos = vector3(429.90, -980.85, 30.71)

Citizen.CreateThread(function()

	local blip = AddBlipForCoord(pos)



	SetBlipSprite (blip, 60)

	SetBlipScale  (blip, 0.85)

	SetBlipColour (blip, 29)

	SetBlipAsShortRange(blip, true)



	BeginTextCommandSetBlipName('STRING')

	AddTextComponentSubstringPlayerName('Commissariat')

	EndTextCommandSetBlipName(blip)

end)
