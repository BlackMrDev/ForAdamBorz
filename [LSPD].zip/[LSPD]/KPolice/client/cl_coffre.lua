ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)



function CoffrePolice()
    local CoffrePolice = RageUI.CreateMenu("Police", "Menu Intéraction..")
    CoffrePolice:SetRectangleBanner(0, 0, 0)
        RageUI.Visible(CoffrePolice, not RageUI.Visible(CoffrePolice))
            while CoffrePolice do
            Citizen.Wait(0)
            RageUI.IsVisible(CoffrePolice, true, true, true, function()

                RageUI.Separator("↓ ~y~   Gestion des stocks  ~s~↓")

                    RageUI.ButtonWithStyle("Retirer un objet(s)",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                        if Selected then
                            PoliceRetire()
                            RageUI.CloseAll()
                        end
                    end)
                    
                    RageUI.ButtonWithStyle("Déposer un objet(s)",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                        if Selected then
                            PoliceDepose()
                            RageUI.CloseAll()
                        end
                    end)
                    
                    
                RageUI.Separator("↓ ~o~   Gestion des armes  ~s~↓")

                RageUI.ButtonWithStyle("Prendre une arme",nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if Selected then
                        OpenGetWeaponMenuPolice()
                        RageUI.CloseAll()
                    end
                end)
    
                RageUI.ButtonWithStyle("Déposer une arme",nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if Selected then
                        OpenPutWeaponMenuPolice()
                        RageUI.CloseAll()
                    end
                end)

                
                end, function()
                end)
            if not RageUI.Visible(CoffrePolice) then
            CoffrePolice = RMenu:DeleteType("CoffrePolice", true)
        end
    end
end

local position = {
    {x = 452.65, y = -982.62, z = 30.69}
}

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(position) do
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)
            DrawMarker(22,  452.65,  -982.62,  30.69, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 40, 158, 18, 255, true, true, p19, true)

            if dist <= 5.0 then
            wait = 0
        
            if dist <= 1.0 then
               wait = 0
			   RageUI.Text({

				message = "Appuyez sur [~r~E~w~] pour ouvrir le coffre",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then
                    exports['progressBars']:startUI((4 * 1000), _U('progbar_talking3'))

                    Citizen.Wait((4 * 1000))
					CoffrePolice()
            end
        end
    end
    end
    Citizen.Wait(wait)
    end
end
end)



function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)


    AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    blockinput = true

    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Citizen.Wait(0)
    end
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult() 
        Citizen.Wait(500) 
        blockinput = false
        return result 
    else
        Citizen.Wait(500) 
        blockinput = false 
        return nil 
    end
end


function OpenGetWeaponMenuPolice()

	ESX.TriggerServerCallback('esx_policejob:getArmoryWeapons', function(weapons)
		local elements = {}

		for i=1, #weapons, 1 do
			if weapons[i].count > 0 then
				table.insert(elements, {
					label = 'x' .. weapons[i].count .. ' ' .. ESX.GetWeaponLabel(weapons[i].name),
					value = weapons[i].name
				})
			end
		end

		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'armory_get_weapon',
		{
			title    = 'Armurerie',
			align    = 'top-left',
			elements = elements
		}, function(data, menu)

			menu.close()

			ESX.TriggerServerCallback('esx_policejob:removeArmoryWeapon', function()
				OpenGetWeaponMenuPolice()
			end, data.current.value)

		end, function(data, menu)
			menu.close()
		end)
	end)

end

function OpenPutWeaponMenuPolice()
	local elements   = {}
	local playerPed  = PlayerPedId()
	local weaponList = ESX.GetWeaponList()

	for i=1, #weaponList, 1 do
		local weaponHash = GetHashKey(weaponList[i].name)

		if HasPedGotWeapon(playerPed, weaponHash, false) and weaponList[i].name ~= 'WEAPON_UNARMED' then
			table.insert(elements, {
				label = weaponList[i].label,
				value = weaponList[i].name
			})
		end
	end

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'armory_put_weapon',
	{
		title    = 'Armurerie',
		align    = 'top-left',
		elements = elements
	}, function(data, menu)

		menu.close()

		ESX.TriggerServerCallback('esx_policejob:addArmoryWeapon', function()
			OpenPutWeaponMenuPolice()
		end, data.current.value, true)

	end, function(data, menu)
		menu.close()
	end)
end


itemstock = {}
function PoliceRetire()
    local PoliceRetire = RageUI.CreateMenu("Police", "Menu Intéraction..")
    ESX.TriggerServerCallback('esx_policejob:prendreitem', function(items) 
    itemstock = items
    RageUI.Visible(PoliceRetire, not RageUI.Visible(PoliceRetire))
        while PoliceRetire do
            Citizen.Wait(0)
                RageUI.IsVisible(PoliceRetire, true, true, true, function()
                        for k,v in pairs(itemstock) do 
                            if v.count ~= 0 then
                            RageUI.ButtonWithStyle(v.label, nil, {RightLabel = v.count}, true, function(Hovered, Active, Selected)
                                if Selected then
                                    local count = KeyboardInput("Combien ?", '' , 8)
                                    TriggerServerEvent('esx_policejob:prendreitems', v.name, tonumber(count))
                                    ExecuteCommand'e pickup'
                                    PoliceRetire()
                                end
                            end)
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(PoliceRetire) then
            PoliceRetire = RMenu:DeleteType("Coffre", true)
        end
    end
end)
end

local PlayersItem = {}
function PoliceDepose()
    local PoliceDepose = RageUI.CreateMenu("Police", "Menu Intéraction..")
    ESX.TriggerServerCallback('esx_policejob:inventairejoueur', function(inventory)
        RageUI.Visible(PoliceDepose, not RageUI.Visible(PoliceDepose))
    while PoliceDepose do
        Citizen.Wait(0)
            RageUI.IsVisible(PoliceDepose, true, true, true, function()
                for i=1, #inventory.items, 1 do
                    if inventory ~= nil then
                            local item = inventory.items[i]
                            if item.count > 0 then
                                        RageUI.ButtonWithStyle(item.label, nil, {RightLabel = item.count}, true, function(Hovered, Active, Selected)
                                            if Selected then
                                            local count = KeyboardInput("Combien ?", '' , 8)
                                            TriggerServerEvent('esx_policejob:stockitem', item.name, tonumber(count))
                                            ExecuteCommand'e pickup'
                                            PoliceDepose()
                                        end
                                    end)
                                end
                            else
                                RageUI.Separator('Chargement en cours')
                            end
                        end
                    end, function()
                    end)
                if not RageUI.Visible(PoliceDepose) then
                PoliceDepose = RMenu:DeleteType("Coffre", true)
            end
        end
    end)
end
