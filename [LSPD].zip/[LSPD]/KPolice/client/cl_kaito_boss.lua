ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}
local PoliceBoss = nil

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


function PoliceBossyy()
    local Shiganshinaaa = RageUI.CreateMenu("Police", "Menu Intéraction..")
    Shiganshinaaa:SetRectangleBanner(0, 0, 0)
      RageUI.Visible(Shiganshinaaa, not RageUI.Visible(Shiganshinaaa))
  
              while Shiganshinaaa do
                  Citizen.Wait(0)
                      RageUI.IsVisible(Shiganshinaaa, true, true, true, function()
  
            if PoliceBoss ~= nil then
                RageUI.ButtonWithStyle("Argent société :", nil, {RightLabel = "$" .. PoliceBoss}, true, function()
                end)
            end

            RageUI.ButtonWithStyle("Retirer argent de société",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                if Selected then
                    local amount = KeyboardInput("Montant", "", 10)
                    amount = tonumber(amount)
                    if amount == nil then
                        RageUI.Popup({message = "Montant invalide"})
                    else
                        TriggerServerEvent('esx_society:withdrawMoney', 'police', amount)
                        RefreshPoliceBoss()
                    end
                end
            end)

            RageUI.ButtonWithStyle("Déposer argent de société",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                if Selected then
                    local amount = KeyboardInput("Montant", "", 10)
                    amount = tonumber(amount)
                    if amount == nil then
                        RageUI.Popup({message = "Montant invalide"})
                    else
                        TriggerServerEvent('esx_society:depositMoney', 'police', amount)
                        RefreshPoliceBoss()
                    end
                end
            end) 

           RageUI.ButtonWithStyle("Accéder aux actions de Management",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                if Selected then
                    aboss()
                    RageUI.CloseAll()
                end
            end)


        end, function()
        end)
        if not RageUI.Visible(Shiganshinaaa) then
        Shiganshinaaa = RMenu:DeleteType("Shiganshinaaa", true)
    end
end
end


local position = {

    {x = 447.96,  y = -973.24,  z = 30.69}

}

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(position) do
            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'boss' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)
            DrawMarker(22,  447.96, -973.24, 30.69, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 0, 0 , 255, true, true, p19, true)

            if dist <= 5.0 then
            wait = 0
        
            if dist <= 1.0 then
               wait = 0
			   RageUI.Text({

				message = "Appuyez sur [~r~E~w~] pour accéder au panel",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then
                    RefreshPoliceBoss()       
                    exports['progressBars']:startUI((4 * 1000), _U('progbar_talking6'))

                    Citizen.Wait((4 * 1000))    
                    PoliceBossyy()
            end
        end
    end
    end
    Citizen.Wait(wait)
    end
end
end)

function RefreshPoliceBoss()
    if ESX.PlayerData.job ~= nil and ESX.PlayerData.job.grade_name == 'boss' then
        ESX.TriggerServerCallback('esx_society:getSocietyMoney', function(money)
            UpdatePoliceBoss(money)
        end, ESX.PlayerData.job.name)
    end
end

function UpdatePoliceBoss(money)
    PoliceBoss = ESX.Math.GroupDigits(money)
end

function aboss()
    TriggerEvent('esx_society:openBossMenu', 'police', function(data, menu)
        menu.close()
    end, {wash = false})
end

function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end

