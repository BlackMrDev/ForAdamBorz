ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)



RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


function PoliceHELICO()
    local PoliceHELICOKaito = RageUI.CreateMenu("Héliport", "Menu Intéraction..")
    PoliceHELICOKaito:SetRectangleBanner(0, 0, 0)
        RageUI.Visible(PoliceHELICOKaito, not RageUI.Visible(PoliceHELICOKaito))
            while PoliceHELICOKaito do
            Citizen.Wait(0)
            RageUI.IsVisible(PoliceHELICOKaito, true, true, true, function()


                    RageUI.ButtonWithStyle("Sortir un Polmav", "Vous sortez un Polmav...", {RightLabel = "→→→"},true, function(Hovered, Active, Selected)
                        if (Selected) then  
                        local model = GetHashKey("polmav")
                        RequestModel(model)
                        while not HasModelLoaded(model) do Citizen.Wait(10) end
                        local pos = GetEntityCoords(PlayerPedId())
                        local vehicle = CreateVehicle(model, 448.69,  -981.65,  43.69,  87.916, true, true)
                        end
                    end)

    
            end, function()
            end, 1)

            if not RageUI.Visible(PoliceHELICOKaito) then
            PoliceHELICOKaito = RMenu:DeleteType("PoliceHELICOKaito", true)
        end
    end
end

local position = {
	{x =  462.14, y = -980.78, z = 43.59}
}

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(position) do
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)

            if dist <= 5.0 then
            wait = 0

        
            if dist <= 2.0 then
               wait = 0
			   RageUI.Text({

				message = "Appuyez sur [~o~E~w~] pour ouvrir le garage",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then

                    local quantity = KeyboardInput("Insérer votre matricule", "", 2)

                    exports['progressBars']:startUI((4000), _U('progbar_talking2'))


                    Citizen.Wait(4000)
                    PoliceHELICO()
            end
        end
    end
    end
    Citizen.Wait(wait)
    end
end
end)



local npc2 = {
	{hash="s_m_y_cop_01", x = 462.14, y = -980.78, z = 43.60, a=106.34}, 
}

Citizen.CreateThread(function()
	for _, item2 in pairs(npc2) do
		local hash = GetHashKey(item2.hash)
		while not HasModelLoaded(hash) do
		RequestModel(hash)
		Wait(20)
		end
		ped2 = CreatePed("PED_TYPE_CIVFEMALE", item2.hash, item2.x, item2.y, item2.z-0.92, item2.a, false, true)
		SetBlockingOfNonTemporaryEvents(ped2, true)
		FreezeEntityPosition(ped2, true)
		SetEntityInvincible(ped2, true)
	end
end)


---- RANGER 



local Etngenant = {
    {x = 448.69,  y = -981.65,  z = 43.69}
}


function okSasuke(vehicle)
    local playerPed = GetPlayerPed(-1)
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local props = ESX.Game.GetVehicleProperties(vehicle)
    local current = GetPlayersLastVehicle(GetPlayerPed(-1), true)
    local engineHealth = GetVehicleEngineHealth(current)

    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then 
        if engineHealth < 890 then
            ESX.ShowNotification("Votre véhicule est trop abimé, vous ne pouvez pas le ranger.")
        else
            ESX.Game.DeleteVehicle(vehicle)
            ESX.ShowNotification("~g~Le Véhicule a été rangé dans le garage.")
        end
    end
end

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(Etngenant) do
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, Etngenant[k].x, Etngenant[k].y, Etngenant[k].z)
            DrawMarker(22,  448.69,  -981.65,  43.69, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 0, 0 , 255, true, true, p19, true)


            if dist <= 5.0 then
            wait = 0
        
            if dist <= 5.0 then
               wait = 0
               if IsPedInAnyVehicle(GetPlayerPed(-1), false) then
			   RageUI.Text({

				message = "Appuyez sur [~r~E~w~] pour ranger ton véhicule",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then
                    
                    DoScreenFadeOut(3000)
                    Citizen.Wait(3000)
                    DoScreenFadeIn(3000)
					okSasuke()
            end
        end
    end
    end
    end
    Citizen.Wait(wait)
    end
end
end)
