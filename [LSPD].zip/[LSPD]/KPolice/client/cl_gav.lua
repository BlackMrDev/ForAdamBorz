ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


function LaGAV()
    local LaGAV = RageUI.CreateMenu("Tenue", "Menu Intéraction..")
    LaGAV:SetRectangleBanner(0, 0, 0)
        RageUI.Visible(LaGAV, not RageUI.Visible(LaGAV))
            while LaGAV do
            Citizen.Wait(0)
            RageUI.IsVisible(LaGAV, true, true, true, function()

 
                RageUI.ButtonWithStyle("Reprendre sa tenue civile",nil, {nil}, true, function(Hovered, Active, Selected)

                    if Selected then

                        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)

                        TriggerEvent('skinchanger:loadSkin', skin)

                        end)

                    end

                end)

    

    

    

                RageUI.ButtonWithStyle("Tenue GAV",nil, {nil}, true, function(Hovered, Active, Selected)

                    if Selected then

                        SetPedComponentVariation(GetPlayerPed(-1) , 8, 39, 0)  

                        SetPedComponentVariation(GetPlayerPed(-1) , 11, 94, 1)  

                        SetPedComponentVariation(GetPlayerPed(-1) , 3, 30, 0) 

                        SetPedComponentVariation(GetPlayerPed(-1) , 4, 46, 0)

                        SetPedComponentVariation(GetPlayerPed(-1) , 6, 24, 0)   

                    end

                end)

    
    
            end, function()
            end, 1)

            if not RageUI.Visible(LaGAV) then
            LaGAV = RMenu:DeleteType("LaGAV", true)
        end
    end
end

local position = {
    {x = 461.58, y = -989.43, z = 24.91}
}

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(position) do
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)
            DrawMarker(22,  461.58,  -989.43,  24.91, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 0, 0 , 255, true, true, p19, true)

            if dist <= 5.0 then
            wait = 0
        
            if dist <= 1.0 then
               wait = 0
			   RageUI.Text({

				message = "Appuyez sur [~r~E~w~] pour vous changez",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then
                    exports['progressBars']:startUI((4 * 1000), _U('progbar_talking9'))

                    Citizen.Wait((4 * 1000))
					LaGAV()
        end
    end
    end
    Citizen.Wait(wait)
    end
end
end)
