ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


function GarageLSPD()
    local GarageLSPDKaito = RageUI.CreateMenu("LSPD", "Menu Intéraction..")
    GarageLSPDKaito:SetRectangleBanner(0, 0, 0)
        RageUI.Visible(GarageLSPDKaito, not RageUI.Visible(GarageLSPDKaito))
            while GarageLSPDKaito do
            Citizen.Wait(0)
            RageUI.IsVisible(GarageLSPDKaito, true, true, true, function()

                RageUI.Separator("↓ ~o~     Modèles de Voitures    ~s~↓")

                RageUI.ButtonWithStyle("Police - Dodge",nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                    local model = GetHashKey("14chrg")
                    RequestModel(model)
                    while not HasModelLoaded(model) do Citizen.Wait(10) end
                    local pos = GetEntityCoords(PlayerPedId())
                    local vehicle = CreateVehicle(model, 448.76, -1021.23, 28.43, 95.3, true, true)
                    end
                end)

                if ESX.PlayerData.job.grade_name == 'officer' or ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'boss' then 
                RageUI.ButtonWithStyle("Police - Buffalo",nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                    local model = GetHashKey("police2")
                    RequestModel(model)
                    while not HasModelLoaded(model) do Citizen.Wait(10) end
                    local pos = GetEntityCoords(PlayerPedId())
                    local vehicle = CreateVehicle(model, 448.76, -1021.23, 28.43, 95.3, true, true)
                    end
                end)
            end

            if ESX.PlayerData.job.grade_name == 'officer' or ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'boss' then 
                RageUI.ButtonWithStyle("Police - Vapid",nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                    local model = GetHashKey("police3")
                    RequestModel(model)
                    while not HasModelLoaded(model) do Citizen.Wait(10) end
                    local pos = GetEntityCoords(PlayerPedId())
                    local vehicle = CreateVehicle(model, 448.76, -1021.23, 28.43, 95.3, true, true)
                    end
                end)
            end


            
            if ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'boss' then 
                RageUI.ButtonWithStyle("Police - SUV",nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                    local model = GetHashKey("nkscout")
                    RequestModel(model)
                    while not HasModelLoaded(model) do Citizen.Wait(10) end
                    local pos = GetEntityCoords(PlayerPedId())
                    local vehicle = CreateVehicle(model, 448.76, -1021.23, 28.43, 95.3, true, true)
                    end
                end)
            end
    
            if ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'boss' then 
                RageUI.ButtonWithStyle("Police - Riot (blindé)",nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                    local model = GetHashKey("riot")
                    RequestModel(model)
                    while not HasModelLoaded(model) do Citizen.Wait(10) end
                    local pos = GetEntityCoords(PlayerPedId())
                    local vehicle = CreateVehicle(model, 448.76, -1021.23, 28.43, 95.3, true, true)
                    end
                end)
            end
    
            end, function()
            end, 1)

            if not RageUI.Visible(GarageLSPDKaito) then
            GarageLSPDKaito = RMenu:DeleteType("GarageLSPDKaito", true)
        end
    end
end

local position = {
	{x = 458.46, y = -1010.45, z = 28.26}
}

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(position) do
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)

            if dist <= 5.0 then
            wait = 0

        
            if dist <= 2.0 then
               wait = 0
			   RageUI.Text({

				message = "Appuyez sur [~o~E~w~] pour sortir une voiture",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then
                    
                    exports['progressBars']:startUI((4 * 1000), _U('progbar_talking'))

                    Citizen.Wait((4 * 1000))
                    GarageLSPD()
            end
        end
    end
    end
    Citizen.Wait(wait)
    end
end
end)



local npc2 = {
	{hash="s_m_y_cop_01", x = 458.46, y = -1010.45, z = 28.16, a=138.12}, 
}

Citizen.CreateThread(function()
	for _, item2 in pairs(npc2) do
		local hash = GetHashKey(item2.hash)
		while not HasModelLoaded(hash) do
		RequestModel(hash)
		Wait(20)
		end
		ped2 = CreatePed("PED_TYPE_CIVFEMALE", item2.hash, item2.x, item2.y, item2.z-0.92, item2.a, false, true)
		SetBlockingOfNonTemporaryEvents(ped2, true)
		FreezeEntityPosition(ped2, true)
		SetEntityInvincible(ped2, true)
	end
end)


local onmelavaitpasditdepuislongtemps = {
    {x = 456.03, y = -1024.1, z = 28.45}
}


function okSasuke(vehicle)
    local playerPed = GetPlayerPed(-1)
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local props = ESX.Game.GetVehicleProperties(vehicle)
    local current = GetPlayersLastVehicle(GetPlayerPed(-1), true)
    local engineHealth = GetVehicleEngineHealth(current)

    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then 
        if engineHealth < 890 then
            ESX.ShowNotification("Votre véhicule est trop abimé, vous ne pouvez pas le ranger.")
        else
            ESX.Game.DeleteVehicle(vehicle)
            ESX.ShowNotification("~g~Le Véhicule a été rangé dans le garage.")
        end
    end
end

Citizen.CreateThread(function()
    while true do

      local wait = 750

        for k in pairs(onmelavaitpasditdepuislongtemps) do
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then 
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, onmelavaitpasditdepuislongtemps[k].x, onmelavaitpasditdepuislongtemps[k].y, onmelavaitpasditdepuislongtemps[k].z)
            DrawMarker(22,  456.03,  -1024.1,  28.45, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 0, 0 , 255, true, true, p19, true)


            if dist <= 5.0 then
            wait = 0
        
            if dist <= 5.0 then
               wait = 0
               if IsPedInAnyVehicle(GetPlayerPed(-1), false) then
			   RageUI.Text({

				message = "Appuyez sur [~r~E~w~] pour ranger ton véhicule",
	
				time_display = 1
	
			})
                if IsControlJustPressed(1,51) then
                    DoScreenFadeOut(3000)
                    Citizen.Wait(3000)
                    DoScreenFadeIn(3000)
					okSasuke()
            end
        end
    end
    end
    end
    Citizen.Wait(wait)
    end
end
end)

